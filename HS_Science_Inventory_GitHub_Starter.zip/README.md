# HS Science Inventory Website

A static, searchable website generated from `HS - SCIENCE Inventory.xlsx`.

## Files
- `index.html` — site layout, styling, search, section tabs, and link rendering.
- `inventory-data.js` — workbook content for all inventory sheets, including cell hyperlinks and URLs found in cells.

## Publish with GitHub Pages
1. Create a GitHub repository (for example, `hs-science-inventory`).
2. Upload `index.html`, `inventory-data.js`, and this `README.md` to the repository root.
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. The URL will appear in the Pages settings.

## Features
- Browse all workbook sections using tabs.
- Search inventory records and optionally limit the search to a field.
- Filter records that contain clickable links.
- Links from Excel hyperlinks are preserved; plain URLs in cells are also made clickable.
- Responsive layout for desktop and mobile.

## Important
The site is a static copy of the workbook at the time it was generated. If the spreadsheet changes, regenerate/update `inventory-data.js`. Chemical safety information is provided for reference only; consult current labels, SDS documents, and complete Hazcards before use.
